#pragma once

#include "person.h"

constexpr int MAX_PERSONS = 100;

class personbook2 {
public:
	bool add(const person& p);
	bool del(int index);
	bool mod(int index, const person& p);
	void clear();
	void list() const;
private:
	person		m_vecPersons[MAX_PERSONS];
	int			m_nsize = 0;
};
